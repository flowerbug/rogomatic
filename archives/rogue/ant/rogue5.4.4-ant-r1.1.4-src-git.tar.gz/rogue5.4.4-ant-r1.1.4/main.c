/*
 * Rogue: Exploring the Dungeons of Doom
 * Copyright (C) 1980-1983, 1985, 1999 Michael Toy, Ken Arnold and Glenn Wichman
 * All rights reserved.
 *
 * See the file LICENSE.TXT for full copyright and licensing information.
 *
 * @(#)main.c	4.22 (Berkeley) 02/05/99
 */

#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <curses.h>
#include "rogue.h"

/*
 * main:
 *	The main program, of course
 */
int
main(int argc, char **argv, char **envp)
{
  char *env;
  int lowtime;

  md_init();

#ifdef MASTER

  /*
   * Check to see if he is a wizard
   */
  if (argc >= 2 && argv[1][0] == '\0')
    if (strcmp(PASSWD, md_crypt(md_getpass("wizard's password: "), "mT")) == 0) {
      wizard = TRUE;
      player.t_flags |= SEEMONST;
      argv++;
      argc--;
    }

#endif

  /*
   * get home and options from environment
   */

  strncpy(home, md_gethomedir(), MAXSTR);

  strcpy(file_name, home);
  strcat(file_name, "rogue.save");

  if ((env = getenv("ROGUEOPTS")) != NULL)
    parse_opts(env);

  if (env == NULL || whoami[0] == '\0')
    strucpy(whoami, md_getusername(), (int) strlen(md_getusername()));

  lowtime = (int) time(NULL);

//#ifdef MASTER
//    if (wizard && getenv("SEED") != NULL)
  if (getenv("SEED") != NULL)
    dnum = atoi(getenv("SEED"));
  else
//#endif
    dnum = lowtime + md_getpid();

  seed = dnum;
  srandom(seed);

  open_score();

  /*
     * Drop setuid/setgid after opening the scoreboard file.
     */

  md_normaluser();

  /*
   * check for print-score option
   */

  md_normaluser(); /* we drop any setgid/setuid priveldges here */

  if (argc == 2) {
    if (strcmp(argv[1], "-s") == 0) {
      noscore = TRUE;
      score(0, -1, 0);
      exit(0);
    }
    else if (strcmp(argv[1], "-d") == 0) {
      dnum = rnd(100);	/* throw away some rnd()s to break patterns */

      while (--dnum)
        rnd(100);

      purse = rnd(100) + 1;
      level = rnd(100) + 1;
      initscr();
      getltchars();
      death(death_monst());
      exit(0);
    }
  }

  init_check();			/* check for legal startup */

  if (argc == 2)
    if (!restore(argv[1], envp))	/* Note: restore will never return */
      my_exit(1);

#ifdef MASTER

  if (wizard)
    printf("Hello %s, welcome to dungeon #%d", whoami, dnum);
  else
#endif
    printf("Hello %s, just a moment while I dig the dungeon #%d...", whoami,dnum);

  fflush(stdout);

  /*
   * Get the process id of this rogue program if the 
   * environment variable is set which requests this be
   * done.  Then create the file name with the PID so
   * that the debugging scripts can find it and use the
   * PID.
   *
   * This code can be removed if you don't need to use
   * the debugging scripts.
   *
   */

  /* Process ID */
  pid_t pid;
  char pidfilename[64];
  FILE *pidfp;

  if (getenv("GETROGUEPID") != NULL) {
    pid = md_getpid ();
    memset (pidfilename, '\0', 64);
    sprintf (pidfilename, "roguepid.%d", pid);
    if ((pidfp = fopen (pidfilename, "w")) == NULL) {
      fprintf (stderr, "Can't open '%s'.\n", pidfilename);
      exit(1);
    }
  }

  initscr();				/* Start up cursor package */
  init_probs();			/* Set up prob tables for objects */
  init_player();			/* Set up initial player stats */
  init_names();			/* Set up names of scrolls */
  init_colors();			/* Set up colors of potions */
  init_stones();			/* Set up stone settings of rings */
  init_materials();			/* Set up materials of wands */
  setup();

  /*
   * The screen must be at least NUMLINES x NUMCOLS
   */
  if (LINES < NUMLINES || COLS < NUMCOLS) {
    printf("\nSorry, the screen must be at least %dx%d\n", NUMLINES, NUMCOLS);
    endwin();
    my_exit(1);
  }

  /*
   * Set up windows
   */
  hw = newwin(LINES, COLS, 0, 0);
  idlok(stdscr, TRUE);
  idlok(hw, TRUE);
#ifdef MASTER
  noscore = wizard;
#endif
  new_level();			/* Draw current level */
  /*
   * Start up daemons and fuses
   */
  start_daemon(runners, 0, AFTER);
  start_daemon(doctor, 0, AFTER);
  fuse(swander, 0, WANDERTIME, AFTER);
  start_daemon(stomach, 0, AFTER);
  playit();
  return(0);
}

/*
 * endit:
 *	Exit the program abnormally.
 */

void
endit(int sig)
{
  NOOP(sig);
  fatal("Okay, bye bye!\n");
}

/*
 * fatal:
 *	Exit the program, printing a message.
 */

void
fatal(char *s)
{
  mvaddstr(LINES - 2, 0, s);
  refresh();
  endwin();
  my_exit(0);
}

/*
 * rnd:
 *	Pick a very random number.
 */
int
rnd(int range)
{
  return range == 0 ? 0 : abs((int) RN) % range;
}

/*
 * roll:
 *	Roll a number of dice
 */
int
roll(int number, int sides)
{
  int dtotal = 0;

  while (number--)
    dtotal += rnd(sides)+1;

  return dtotal;
}

/*
 * tstp:
 *	Handle stop and start signals
 */

void
tstp(int ignored)
{
  int y, x;
  int oy, ox;

  NOOP(ignored);

  /*
   * leave nicely
   */
  getyx(curscr, oy, ox);
  mvcur(0, COLS - 1, LINES - 1, 0);
  endwin();
  resetltchars();
  fflush(stdout);
  md_tstpsignal();

  /*
   * start back up again
   */
  md_tstpresume();
  raw();
  noecho();
  keypad(stdscr,1);
  playltchars();
  clearok(curscr, TRUE);
  wrefresh(curscr);
  getyx(curscr, y, x);
  mvcur(y, x, oy, ox);
  fflush(stdout);
#ifdef NCURSES_OPAQUE
  wmove(curscr, oy, ox);
#else
  curscr->_cury = oy;
  curscr->_curx = ox;
#endif /* NCURSES_OPAQUE */
}

/*
 * playit:
 *	The main loop of the program.  Loop until the game is over,
 *	refreshing things and looking at the proper times.
 */

void
playit()
{
  char *opts;

  /*
   * set up defaults for slow terminals
   */

  if (baudrate() <= 1200) {
    terse = TRUE;
    jump = TRUE;
    see_floor = FALSE;
  }

  if (md_hasclreol())
    inv_type = INV_CLEAR;

  /*
   * parse environment declaration of options
   */
  if ((opts = getenv("ROGUEOPTS")) != NULL)
    parse_opts(opts);


  oldpos = hero;
  oldrp = roomin(&hero);

  while (playing)
    command();			/* Command execution */

  endit(0);
}

/*
 * quit:
 *	Have player make certain, then exit.
 */

void
quit(int sig)
{
  int oy, ox;

  NOOP(sig);

  /*
   * Reset the signal in case we got here via an interrupt
   */
  if (!q_comm)
    mpos = 0;

  getyx(curscr, oy, ox);
  msg("really quit?");

  if (readchar() == 'y') {
    signal(SIGINT, leave);
    clear();
    mvprintw(LINES - 2, 0, "You quit with %d gold pieces", purse);
    move(LINES - 1, 0);
    refresh();
    score(purse, 1, 0);
    my_exit(0);
  }
  else {
    move(0, 0);
    clrtoeol();
    status();
    move(oy, ox);
    refresh();
    mpos = 0;
    count = 0;
    to_death = FALSE;
  }
}

/*
 * leave:
 *	Leave quickly, but curteously
 */

void
leave(int sig)
{
  static char buf[BUFSIZ];

  NOOP(sig);

  setbuf(stdout, buf);	/* throw away pending output */

  if (!isendwin()) {
    mvcur(0, COLS - 1, LINES - 1, 0);
    endwin();
  }

  putchar('\n');
  my_exit(0);
}

/*
 * shell:
 *	Let them escape for a while
 */

void
shell()
{
  /*
   * Set the terminal back to original mode
   */
  move(LINES-1, 0);
  refresh();
  endwin();
  resetltchars();
  putchar('\n');
  in_shell = TRUE;
  after = FALSE;
  fflush(stdout);
  /*
   * Fork and do a shell
   */
  md_shellescape();

  printf("\n[Press return to continue]");
  fflush(stdout);
  noecho();
  raw();
  keypad(stdscr,1);
  playltchars();
  in_shell = FALSE;
  wait_for('\n');
  clearok(stdscr, TRUE);
}

/*
 * my_exit:
 *	Leave the process properly
 */

void
my_exit(int st)
{
  int i;
  THING *item;

  /* free up names, monsters and items used */
  for(i = 0; i < MAXSCROLLS; i++)
    if (s_names[i] != NULL) {
      free(s_names[i]);
      s_names[i] = NULL;
    }

  for (item = mlist; item != NULL; item = next(item))
    free_list(item->t_pack);

  free_list(pack);
  free_list(mlist);
  free_list(lvl_obj);

  resetltchars();
  exit(st);
}
