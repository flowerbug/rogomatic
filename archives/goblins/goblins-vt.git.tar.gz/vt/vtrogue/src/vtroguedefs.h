#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* A simple scanner for Rogue control character tokens */


#define YYERROR_VERBOSE


/* use one or none of these three PRT defines, but not more 
   than one (unless you want duplicated and strange output).
   using none means that only unrecognized characters are 
   passed through (i.e. errors that should be fixed by adding
   a new pattern). */

/* print lexical debugging information */
#define PRTL  /* this one is defined by default */

/* break each character/code into one line */
//#define PRTB

/* print only printable characters (remove all escape codes) */
//#define PRTP

/* undefining all of them means that only unrecognized 
   characters should be passed through (i.e. errors which
   should be fixed somehow) */


/* the list of return codes for the scanner */

#define EOF_TOK -1   /* End of File */
#define ERR_TOK -2   /* Error */
#define UNK_TOK -3   /* unknown, strange or funny business */

#define BS_TOK -4    /* Move left by one */
#define CB_TOK -5    /* Clear to beginning of line */
#define CE_TOK -6    /* Clear screen */
#define CL_TOK -7    /* Clear screen and go to home 0,0 */
#define CM_TOK -8    /* Move to position number1, number2 */
#define CR_TOK -9    /* Move to column 0 */
#define CS_TOK -10   /* Change scroll region to number1 - number2 */
#define EN_TOK -11   /* Enable alternate character set */
#define HM_TOK -12   /* Go to home 0,0 */
#define KE_TOK -13   /* End keyboard transmit mode */
#define KS_TOK -14   /* Start keyboard transmit mode */
#define LF_TOK -15   /* Line feed, move down one row */
#define MG_TOK -16   /* Turn on margins */
#define ND_TOK -17   /* Move down number1 rows */
#define NL_TOK -18   /* Move left number1 cols */
#define NR_TOK -19   /* Move right number1 cols */
#define NU_TOK -20   /* Move up number1 rows */
#define RC_TOK -21   /* Restore cursor */
#define SC_TOK -22   /* Save cursor */
#define SE_TOK -23   /* End standout mode */
#define SO_TOK -24   /* Start standout mode */
#define SR_TOK -25   /* Scroll text down */

