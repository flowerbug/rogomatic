#include "vtrogomaticdefs.h"

/* The main program, printing and error handling functions. */


extern unsigned long yylineno;
extern char yytext[80];
extern int yynum, yyrow, yycol;


/* print str if a flag is defined otherwise be quiet */
void prt(char* str)

{

#ifdef PRTB
  printf("\n%s\n",str);
#endif
#ifdef PRTL
  printf("%s",str);
#endif

} /* prt */


/* when something goes wrong */
void yyerror(const char *line)

{

fprintf(stderr,"%s in Line %ld\n",line,yylineno);

} /* yyerror */


int main(
	int argc,
  char **argv)

{

while (yylex() != EOF);

}  /* main */
