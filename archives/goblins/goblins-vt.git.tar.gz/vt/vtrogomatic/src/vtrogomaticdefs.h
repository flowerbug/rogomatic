#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* A simple scanner for Rogue control character tokens */


#define YYERROR_VERBOSE


/* use one or none of these three PRT defines, but not more 
   than one (unless you want duplicated and strange output).
   using none means that only unrecognized characters are 
   passed through (i.e. errors that should be fixed by adding
   a new pattern). */

/* print lexical debugging information */
#define PRTL  /* this one is defined by default */

/* break each character/code into one line */
//#define PRTB

/* print only printable characters (remove all escape codes) */
//#define PRTP

/* undefining all of them means that only unrecognized 
   characters should be passed through (i.e. errors which
   should be fixed somehow) */



/* the list of return codes for the scanner */

#define EOF_TOK -1   /* End of File */
#define ERR_TOK -2   /* Error */
#define UNK_TOK -3   /* Unknown, strange or funny business */

#define BS_TOK -4    /* Move left by one */
#define CB_TOK -5    /* Clear to beginning of line */
#define CE_TOK -6    /* Clear screen */
#define CH_TOK -7    /* Horizontal pos absolute */
#define CL_TOK -8    /* Clear screen and go to home 0,0 */
#define CM_TOK -9    /* Move to position number1, number2 */
#define CR_TOK -10   /* Move to column 0 */
#define CS_TOK -11   /* Change scroll region to number1 - number2 */
#define CV_TOK -12   /* Vertical pos absolute */
#define DC_TOK -13   /* Delete number1 characters */
#define EI_TOK -14   /* Exit insert mode */
#define HM_TOK -15   /* Go to home 0,0 */
#define KE_TOK -16   /* End keyboard transmit mode */
#define LF_TOK -17   /* Line feed, move down one row */
#define ME_TOK -18   /* Turn off all attributes */
#define MG_TOK -19   /* Turn on margins */
#define RC_TOK -20   /* Restore cursor */
#define RI_TOK -21   /* Move number1 characters right */
#define RV_TOK -22   /* End alt char set, then reverse video */
#define SC_TOK -23   /* Save cursor */
#define SF_TOK -24   /* Scroll forward number1 lines */
#define SN_TOK -25   /* Scroll number1 lines */
#define SR_TOK -26   /* Scroll text down */
#define TE_TOK -27   /* Exit_ca_mode string to end programs using cup */
#define TI_TOK -28   /* Enter_ca_mode string to start programs using cup */
#define UP_TOK -29   /* Up one row */

