This is the source for the Roguelike Gallery's versions of Rogue and other
early roguelike games.

The code was obtained from the Roguelike Restoration Project
(rogue.rogueforge.net).  Modifications have been made mainly for compatibility
with the dgamelaunch online play system.  Some bugs have also been fixed, and
the build process slightly improved.  The essential flavor of a codebase half
as old as stored-program computing machinery remains unchanged.

Advanced Rogue 7 and XRogue were recently added and are still in an
experimental state.

To install on Unix (including OS X):

If you checked out the source from Mercurial, run 'autoreconf' first.

Build by running './configure' and then 'make'.  If you just want to play the 
game from your own user account, 'configure' won't need any options.  The 
games will keep the high score lists in whatever directory you run them from.

For a multi-user installation, you will need to set the '--enable-setgid',
'--enable-savedir', '--enable-scorefile', and '--enable-logfile' options.  Run
'make install' after building.

There are other possible options; run './configure --help' for a full list.

To install on Windows:

Use the included Visual Studio solution files.  Warning: they have not been 
tested recently.

You can also build on Windows using MinGW.  Make sure pdcurses is installed.
You will have to go into the '/lib' folder and copy 'libpdcurses.a' to
'libcurses.a', and 'libpdcurses.dll.a' to 'libcurses.dll.a'; this should get
fixed soon.

It is recommended to run 'configure' with the '--disable-logfile' option, and
'make' with the 'LDFLAGS=-static' option.

The games should all build with MinGW and run, but Super-Rogue has problems
with restoring saved games.

See the individual games' subdirectories for further documentation.  Some of 
the manpages may be outdated, but the guides to playing should be accurate.

The games can be played via SSH or the Web at rlgallery.org.

Bugs:

The original authors claimed that the list of bugs was "probably infinite".  If 
you encounter one of these, please report it on the bug tracker at 
https://bitbucket.org/ElwinR/rl.
