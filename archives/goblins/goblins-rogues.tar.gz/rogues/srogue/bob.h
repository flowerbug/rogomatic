/*
 * Super-Rogue
 * Copyright (C) 1984 Robert D. Kindelberger
 * All rights reserved.
 *
 * See the file LICENSE.TXT for full copyright and licensing information.
 */

#include	<sgtty.h>
typedef	struct sgttyb	SGTTY;
static SGTTY _tty, _res_flg;

