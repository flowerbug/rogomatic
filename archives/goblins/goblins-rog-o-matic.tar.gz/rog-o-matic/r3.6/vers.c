/*
 * version number.  Whenever a new version number is desired, use
 * sccs to get vers.c.  Environ and encstr are declared here to
 * force them to be loaded before the version number, and therefore
 * not to be written in saved games.
 */

char encstr[] = "\354\251\243\332A\201|\301\321p\210\251\327\"\257\365t\341%3\271^`~\203z{\341};\f\341\231\222e\234\351]\321";
char version[] = "@(#)vers.c	3.6 (Berkeley) 4/21/81";
char *release = "3.6";
