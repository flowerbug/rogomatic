#!/bin/bash

# Install script for Roguelike Restoration Project Fork's Rogue v5.4.
# Runs configure, Makefile, etc. with RRPF's standard installation settings
# (for consistency with the other RRPF versions)
#

# This shell script configures, makes, and installs RRPF Rogue v5.4
# and cleans the source directory.
#
# NOTE: Must be run as superuser.

# Copyright (C) 2012-2014 Rogue Central @ coredumpcentral.org.
# All Rights Reserved.
# See LICENSE.CDC for important information.

# Want wizard mode? Be a computer wizard and figure it out.
# It's very easy! Hint: You only have to modify this shell script.

INSTALL=/usr/bin/install
MAKE=/usr/bin/make
RM=/bin/rm

./configure --enable-scorefile=/usr/local/var/rrpf/rogue54.scr --enable-lockfile=/tmp/rogue54.lck --with-ncurses --with-program-name=rogue54

if [ $? != 0 ]; then
	exit 
fi

$MAKE

if [ $? != 0 ]; then
       	exit
fi

$INSTALL --directory /usr/local/var
$INSTALL --directory /usr/local/var/rrpf
$INSTALL --directory /usr/local/games
$INSTALL --directory /usr/local/man
$INSTALL --directory /usr/local/man6
$INSTALL --directory /usr/local/doc
$INSTALL --directory /usr/local/rogue
$INSTALL --directory /usr/local/rogue/rrpf
$INSTALL --mode=755 rogue54 /usr/local/games
$INSTALL --mode=644 rogue.6 /usr/local/man/man6/rogue54.6
$INSTALL --mode=644 LICENSE.54 /usr/local/doc/rogue/rrpf
$INSTALL --mode=644 rogue.6 /usr/local/doc/rogue/rrpf/rogue54.6
$INSTALL --mode=644 rogue.doc /usr/local/doc/rogue/rrpf/rogue54.doc
$INSTALL --mode=644 rogue.html /usr/local/doc/rogue/rrpf/rogue54.html
$INSTALL --mode=644 rogue54.png /usr/local/doc/rogue/rrpf
$INSTALL --group=games --mode=664 rogue54.scr /usr/local/var/rrpf

$RM -v Makefile rogue.6 rogue.cat rogue.doc rogue.html rogue.me config.status config.h rogue54 *.o
